package com.example.myapplication;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.io.IOException;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    ImageView imgvw;
    Uri originalimg;
    Bitmap originalBitmap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        imgvw = (ImageView) findViewById(R.id.imageView);

    }

    int SELECT_CODE = 1;

    public void LoadPic(View v){
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Title"),SELECT_CODE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1 && resultCode ==RESULT_OK && data != null){
            originalimg = data.getData();
            try {
                originalBitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), originalimg );
            } catch (IOException e) {
                e.printStackTrace();
            }
            imgvw.setImageBitmap(originalBitmap);
            Button toAMAC = (Button)findViewById(R.id.toAMAC);
            toAMAC.setVisibility(View.VISIBLE);
            TextView keyEntery = (TextView)findViewById(R.id.Key_Entry);
            keyEntery.setVisibility(View.VISIBLE);
            EditText key = (EditText)findViewById(R.id.Key);
            key.setVisibility(View.VISIBLE);
        }
    }

    //AMAC----------------------------------------------------------
    public void ToAMAC(View V){
        TextView keyEntery = (TextView)findViewById(R.id.Key_Entry);
        keyEntery.setVisibility(View.INVISIBLE);
        EditText key = (EditText)findViewById(R.id.Key);
        key.setVisibility(View.INVISIBLE);
        String seed = String.valueOf(key.getText());
        Button b3 = (Button)findViewById(R.id.toAMAC);
        b3.setVisibility(View.INVISIBLE);
        Button b4 = (Button)findViewById(R.id.button);
        b4.setVisibility(View.INVISIBLE);
        TextView hv = (TextView) findViewById(R.id.HashView);
        hv.setVisibility(View.VISIBLE);




        //Resizing to 256*256
        Bitmap resizedImage = Bitmap.createScaledBitmap(originalBitmap, 256, 256, true);
        originalBitmap = resizedImage;
        imgvw.setImageBitmap(originalBitmap);


        //Getting pixel values and greyscaling
        int height=originalBitmap.getHeight();
        int width=originalBitmap.getWidth();
        int[][] pixelvalues = new int[height][width];
        int[][] originalPixelValues = new int[height][width];


        int redValue=0;
        int blueValue=0;
        int greenValue=0;
        int total =0;

        for(int p=0; p<height; p++){
            for(int l=0; l<width; l++){
                pixelvalues[p][l]=originalBitmap.getPixel(p,l);
                redValue = Color.red(pixelvalues[p][l]);
                blueValue = Color.blue(pixelvalues[p][l]);
                greenValue = Color.green(pixelvalues[p][l]);
                total = (redValue + blueValue + greenValue) / 3;
                originalPixelValues[p][l] = total;
            }
            total = 0;
        }

        int[] temporary=new int[1024];

        int summ = 0;
        int col = 0;

        for(int i=0; i<256; i=i+8){
            for(int j=0; j<256; j=j+8){
                for(int x=i; x<i+8; x++){
                    for(int y=j; y<j+8; y++){
                        summ = summ + originalPixelValues[x][y];
                    }
                }
                temporary[col]= summ/64;
                col++;
                summ = 0;
            }
        }

        int[][] MeanOfPixelValues =new int[32][32];

        for(int g=0; g<32; g++){
            for(int f=0; f<32; f++){
                MeanOfPixelValues[g][f]= temporary[(g*32)+f];
            }
        }


        //padding
        int numOfPads = 1;
        int[][] Padded = new int[MeanOfPixelValues.length + numOfPads][MeanOfPixelValues[0].length + numOfPads];
        for (int i = 0; i < Padded.length; i++) {
            for (int j = 0; j < Padded[i].length; j++) {
                Padded[i][j] = 0;
            }
        }
        for (int i = 0; i < MeanOfPixelValues.length; i++) {
            for(int j = 0; j < MeanOfPixelValues[i].length; j++) {
                Padded[i+numOfPads][j+numOfPads] = MeanOfPixelValues[i][j];
            }
        }


        //MSB
        for(int i=0; i<33; i++){
            for(int j=0; j<33; j++){
                Padded[i][j] = Padded[i][j] >>> 7;
            }
        }


        //getting key and making the random permutation with it
        int KEY= Integer.parseInt(seed);
        int[] permut = new int[33];
        Random random = new Random(KEY);
        permut[0]=random.nextInt(33);
        for(int i=1; i<33; i++){
            for(int j=i; j<33; j++){
                if (i == j) {
                    continue;
                }
                if (permut[i] == permut[j]){
                    int replacement = random.nextInt(33);
                    boolean duplicate = true;
                    do {
                        try {
                            permut[j] = replacement;
                            for (int k = 0; k < j; k++) {
                                if (permut[j] == permut[k]) {
                                    throw new Exception();
                                }
                            }
                            duplicate = false;
                        } catch (Exception e) {
                            replacement = random.nextInt(33);
                        }
                    } while (duplicate);

                }
            }
        }


        //Swaping rows according to random permutation
        int[][] permuted = new int[33][33];
        for(int k=0, i=0; k<33 && i<33; k++, i++){

                for(int j=0; j<33; j++){
                    permuted[i][j]= Padded[permut[k]][j];
                }
        }


        //making a random binary 33*33 matrix caleed T with seed
        int[][] T= new int[33][33];
        for(int i=0; i<33; i++){
            for(int j=0; j<33; j++){
                T[i][j]=random.nextInt(2);
            }
        }


        //XOR-ing T with permuted
        hv.append("\n");
        for(int i=0; i<33; i++){
            for(int j=0; j<33; j++){
                permuted[i][j] = T[i][j]^permuted[i][j];
            }
        }


        //Majority first round
        int[][] FRM = new int[11][33];
        int counter=0;
        int zeros = 0;
        int ones = 0;
        int i=0;
        int z=0;
        for(int k=0; k<11; ){
            for(int h=0; h<33; ){
                for(int j=0; j<33; j++){
                    for( ; i<33; ){
                        if(counter<=2){
                            if(permuted[i][j]==0){
                                zeros++;
                            }
                            else{
                                ones++;
                            }
                            counter++;
                            if(counter<3){
                                i++;
                            }
                        }
                        else{
                            if(zeros>ones){
                                FRM[k][h]=0;
                            }
                            else{
                                FRM[k][h]=1;
                            }
                            counter = 0;
                            zeros=0;
                            ones=0;
                            h++;
                            i=z;
                            break;
                        }
                    }
                }
                if(i<33) {
                    i = i + 3;
                    z = i;
                    k++;
                }
            }
        }


        //Majority Final round
        int[] FinalMajority = new int[33];
        int _0s=0;
        int _1s=0;
        counter=0;
        for(int h=0; h<33; h++){
            for(int k=0; k<11; k++){
                if(counter<11){
                    if(FRM[k][h]==0){
                        _0s++;
                    }
                    else{
                        _1s++;
                    }
                    counter++;
                    if(counter==11){
                        if(_0s>_1s){
                            FinalMajority[h] = 0;
                        }
                        else if(_0s<_1s){
                            FinalMajority[h] = 1;
                        }
                        counter=0;
                        _0s=0;
                        _1s=0;
                    }
                }
            }
        }


        String s = "";
        for(int k=0; k<32; k++) {
            s= s+ String.valueOf(FinalMajority[k]);
        }

        int decimal = Integer.parseInt(s,2);
        String hexStr = Integer.toString(decimal,16);
        hv.append(hexStr+String.valueOf(FinalMajority[32]));
    }
}